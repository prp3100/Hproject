# อ่านภาพที่มีข้อความลับ
with open("Gay pikachu.png", "rb") as image_file: 
    content = image_file.read()


hidden_message = content.split(b"===SECRET===")[-1]


print("รหัสผ่านในภาพคือ:", hidden_message.decode("utf-8"))
#ถ้ารันไม่ได้ต้องเปิดไฟล์แบบ open folder